import {
  require_react
} from "./chunk-W4EHDCLL.js";
import "./chunk-EWTE5DHJ.js";
export default require_react();
