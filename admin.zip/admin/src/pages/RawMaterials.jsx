import React from 'react'

function RawMaterials() {
  return (
      <div className="RawMaterial">

      </div>
  )
}

export default RawMaterials